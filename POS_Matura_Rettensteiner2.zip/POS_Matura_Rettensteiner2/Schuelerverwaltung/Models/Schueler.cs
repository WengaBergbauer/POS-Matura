﻿namespace Schuelerverwaltung.Models
{
	public class Schueler
	{
        public int Id { get; set; }
        public string Vorname { get; set; }
		public string Nachname { get; set; }
		public string Klasse {  get; set; }
		public bool IsActive { get; set; } = true;
		public float? Note { get; set; }
	}
}
