﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.Internal;
using Schuelerverwaltung.Data;
using Schuelerverwaltung.Models;
using System.Diagnostics;

namespace Schuelerverwaltung.Controllers
{
	public class HomeController : Controller
	{
		private readonly ILogger<HomeController> _logger;
		private readonly ApplicationDbContext _context;

		public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
		{
			_logger = logger;
			_context = context;
		}

		public IActionResult Index()
		{
            if (User.Identity.Name != null)
			{
                Professor? current = null;
                current = _context.professoren.Include(element => element.Schueler).FirstOrDefault(element => element.OwnerUser == User.Identity.Name);
                return View("Index", current);
            }
			else
			{
				List<Professor> all = new List<Professor>(_context.professoren.Include(element => element.Schueler));
				return View("Index", all);
			}
        }

		public IActionResult RegisterEditProfessor()
		{
            Professor? current = _context.professoren.FirstOrDefault(element => element.OwnerUser == User.Identity.Name);

			List<SelectListItem> list = new List<SelectListItem>();
            SelectListItem item0 = new SelectListItem("Keine", null);
            SelectListItem item1 = new SelectListItem("Informatik", "INF");
            SelectListItem item2 = new SelectListItem("Elektrotechnik", "ET");
            SelectListItem item3 = new SelectListItem("Bautechnik", "BT");
            SelectListItem item4 = new SelectListItem("Machatronik", "ME");

            list.Add(item0);
            list.Add(item1);
            list.Add(item2);
            list.Add(item3);
            list.Add(item4);

            ViewData["Abteilungen"] = list;
            return View(current);
		}

        public IActionResult SubmitProfessor(Professor professor)
		{
			if(professor.Id == 0)
			{
				professor.OwnerUser = User.Identity.Name;
				_context.professoren.Add(professor);
				_context.SaveChanges();
			}
			else
			{
				Professor? fromDB = _context.professoren.FirstOrDefault(e => e.OwnerUser == User.Identity.Name);

				if(fromDB != null)
				{
					fromDB.Vorname = professor.Vorname;
					fromDB.Nachname = professor.Nachname;
					fromDB.Email = professor.Email;
					fromDB.Titel = professor.Titel;
					fromDB.Abteilung = professor.Abteilung;
					_context.SaveChanges();
				}
				else
				{
					return Error();
				}
			}

            return RedirectToAction("Index");
        }

        public IActionResult CreateEditSchueler(int? Id)
		{
			if (Id != null) {
				Schueler? selected = _context.schueler.FirstOrDefault(e => e.Id == Id);
                return View(selected);
            }
            else
			{
                return View();
            }
        }

		public IActionResult SubmitSchueler(Schueler schueler)
		{
            if (schueler.Id == 0)
            {
				Professor current = _context.professoren.First(element => element.OwnerUser == User.Identity.Name);
				current.Schueler.Add(schueler);
                _context.SaveChanges();
            }
            else
            {
                Schueler? fromDB = _context.schueler.FirstOrDefault(e => e.Id == schueler.Id);

                if (fromDB != null)
                {
                    fromDB.Vorname = schueler.Vorname;
                    fromDB.Nachname = schueler.Nachname;
                    fromDB.Klasse = schueler.Klasse;
                    fromDB.IsActive = schueler.IsActive;
                    fromDB.Note = (schueler.Note + fromDB.Note) / 2;
                    _context.SaveChanges();
                }
                else
                {
                    return Error();
                }
            }

            return RedirectToAction("Index");
		}

        public IActionResult Privacy()
		{
			return View();
		}


		[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
		public IActionResult Error()
		{
			return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
		}
	}
}
