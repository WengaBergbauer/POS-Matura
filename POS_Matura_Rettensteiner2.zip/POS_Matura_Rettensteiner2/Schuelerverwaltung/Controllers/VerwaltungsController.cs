﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Schuelerverwaltung.Data;
using Schuelerverwaltung.Models;
using System.ComponentModel.Design;
using System.Text.Json;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Schuelerverwaltung.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VerwaltungsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public VerwaltungsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/<VerwaltungsController>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<VerwaltungsController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<VerwaltungsController>
        [HttpPost("getSchueler")]
        public List<Schueler> Post([FromBody] object json)
        {
            string teacher = json.ToString();
            Console.WriteLine(teacher);

            Professor? professor = _context.professoren.Include(e => e.Schueler).FirstOrDefault(e => e.Nachname == teacher);

            if(professor != null) { 
                return professor.Schueler;
            }
            else
            {
                return null;
            }

        }
    }
}
