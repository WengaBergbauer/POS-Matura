﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Schuelerverwaltung.Data.Migrations
{
    /// <inheritdoc />
    public partial class init : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "professoren",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Vorname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Nachname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    titel = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    abteilung = table.Column<int>(type: "int", nullable: true),
                    OwnerUser = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_professoren", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "schueler",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Vorname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Nachname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    klasse = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isActive = table.Column<bool>(type: "bit", nullable: false),
                    note = table.Column<int>(type: "int", nullable: true),
                    ProfessorId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_schueler", x => x.Id);
                    table.ForeignKey(
                        name: "FK_schueler_professoren_ProfessorId",
                        column: x => x.ProfessorId,
                        principalTable: "professoren",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_schueler_ProfessorId",
                table: "schueler",
                column: "ProfessorId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "schueler");

            migrationBuilder.DropTable(
                name: "professoren");
        }
    }
}
