﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Schuelerverwaltung.Data.Migrations
{
    /// <inheritdoc />
    public partial class init2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "titel",
                table: "professoren",
                newName: "Titel");

            migrationBuilder.RenameColumn(
                name: "email",
                table: "professoren",
                newName: "Email");

            migrationBuilder.RenameColumn(
                name: "abteilung",
                table: "professoren",
                newName: "Abteilung");

            migrationBuilder.AlterColumn<string>(
                name: "Abteilung",
                table: "professoren",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Titel",
                table: "professoren",
                newName: "titel");

            migrationBuilder.RenameColumn(
                name: "Email",
                table: "professoren",
                newName: "email");

            migrationBuilder.RenameColumn(
                name: "Abteilung",
                table: "professoren",
                newName: "abteilung");

            migrationBuilder.AlterColumn<int>(
                name: "abteilung",
                table: "professoren",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);
        }
    }
}
