﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Schuelerverwaltung.Models;
using System.Security.Permissions;

namespace Schuelerverwaltung.Data
{
	public class ApplicationDbContext : IdentityDbContext
	{
		public DbSet<Professor> professoren {  get; set; }
		public DbSet<Schueler> schueler { get; set; }


		public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
			: base(options)
		{
		}
	}
}
