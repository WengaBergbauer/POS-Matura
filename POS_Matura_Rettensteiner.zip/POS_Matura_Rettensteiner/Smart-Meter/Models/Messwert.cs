﻿namespace Smart_Meter.Models
{
    public class Messwert
    {
        public int Id { get; set; }
        public float Value { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
        public int ZaehlerId { get; set; }
    }
}
