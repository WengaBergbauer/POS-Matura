﻿namespace Smart_Meter.Models
{
    public class Kunde
    {
        public int Id { get; set; }
        public string Vorname { get; set; }
        public string Nachname { get; set; }
        public string Anschrift { get; set; }
        public string Email { get; set; }
        public bool OptIn { get; set; } = true;
        public List<Zaehler> ZaehlerList { get; set; } = new List<Zaehler>();
        public string? OwnerUser { get; set; }

    }
}
