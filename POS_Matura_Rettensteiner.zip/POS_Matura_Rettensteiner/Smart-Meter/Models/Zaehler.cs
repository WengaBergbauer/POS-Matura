﻿namespace Smart_Meter.Models
{
    public class Zaehler
    {
        public int Id { get; set; }
        public string MacAdresse { get; set; }
        public List<Messwert> Messwerte { get; set; } = new List<Messwert>();
    }
}
