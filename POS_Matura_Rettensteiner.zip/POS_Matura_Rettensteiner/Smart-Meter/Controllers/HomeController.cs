﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Smart_Meter.Data;
using Smart_Meter.Models;
using System.Diagnostics;

namespace Smart_Meter.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;

        public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            string? currentUser = User.Identity.Name;


            if(currentUser != null)
            {
                Kunde? kunde = _context.Kunden
                    .Include(k => k.ZaehlerList)
                    .ThenInclude(z => z.Messwerte)
                    .FirstOrDefault(k => k.OwnerUser == currentUser);

                List<Preis> preise = _context.Preise.ToList();
                ViewData["Preise"] = preise;
                return View("Index", kunde);
            }
            else
            {
                return View("Index", null);
            }
        }

        public IActionResult AddCredentials(Kunde? kunde)
        {
            if(kunde != null)
            {
                kunde.OwnerUser = User.Identity.Name;

                Kunde? dbKunde = _context.Kunden.FirstOrDefault(k => k.Id == kunde.Id);

                if(dbKunde != null)
                {
                    dbKunde.Vorname = kunde.Vorname;
                    dbKunde.Nachname = kunde.Nachname;
                    dbKunde.Anschrift = kunde.Anschrift;
                    dbKunde.Email = kunde.Email;
                    dbKunde.OptIn = kunde.OptIn;
                    dbKunde.OwnerUser = kunde.OwnerUser;

                    kunde = dbKunde;
                }
                else
                {
                    _context.Kunden.Add(kunde);
                }
                _context.SaveChanges();


                return Index();
            }
            else
            {
                return Error();
            }
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}