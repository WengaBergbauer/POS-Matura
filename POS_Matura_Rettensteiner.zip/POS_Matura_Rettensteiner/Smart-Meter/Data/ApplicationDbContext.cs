﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Smart_Meter.Models;

namespace Smart_Meter.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public DbSet<Kunde> Kunden { get; set; }
        public DbSet<Preis> Preise { get; set; }
        public DbSet<Messwert> Messwerte { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
    }
}